import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { getCurrentUser, getUserScore, logout } from '@/utils/userManager';
import { useEffect, useState } from 'react';

const Index = () => {
  const navigate = useNavigate();
  const [currentUser, setCurrentUser] = useState<string | null>(null);

  useEffect(() => {
    const user = getCurrentUser();
    if (!user) {
      navigate('/auth');
    } else {
      setCurrentUser(user);
    }
  }, [navigate]);

  const handleLogout = () => {
    logout();
    navigate('/auth');
  };

  const games = [
    {
      title: 'Ball Rider',
      description: 'Esquivez les obstacles sur la route',
      gradient: 'from-blue-500 to-purple-600',
      path: '/ballrider',
    },
    {
      title: 'Happy Snake',
      description: 'Faites grandir votre cube sans toucher les murs',
      gradient: 'from-green-500 to-teal-600',
      path: '/happysnake',
    },
    {
      title: 'Briks',
      description: 'Alignez les blocs pour marquer des points',
      gradient: 'from-orange-500 to-red-600',
      path: '/briks',
    },
  ];

  if (!currentUser) return null;

  return (
    <div className="min-h-screen bg-gradient-to-br from-background via-muted to-background">
      {/* Header */}
      <header className="border-b bg-card/50 backdrop-blur-sm sticky top-0 z-50">
        <div className="container mx-auto px-4 py-4 flex justify-between items-center">
          <h1 className="text-2xl font-bold bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">
            Plateforme de Jeux 3D
          </h1>
          <div className="flex items-center gap-4">
            <span className="text-sm text-muted-foreground">
              Joueur: <span className="font-semibold text-foreground">{currentUser}</span>
            </span>
            <Button variant="outline" onClick={handleLogout}>
              Déconnexion
            </Button>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="container mx-auto px-4 py-16 text-center">
        <h2 className="text-5xl font-bold mb-4 bg-gradient-to-r from-primary via-accent to-primary bg-clip-text text-transparent animate-pulse">
          Bienvenue dans l'Univers 3D
        </h2>
        <p className="text-xl text-muted-foreground mb-8">
          Trois jeux immersifs créés avec Three.js
        </p>
      </section>

      {/* Games Grid */}
      <section className="container mx-auto px-4 py-12">
        <div className="grid md:grid-cols-3 gap-8">
          {games.map((game) => {
            const gameKey = game.path.substring(1) as 'ballrider' | 'happysnake' | 'briks';
            const bestScore = getUserScore(gameKey);
            
            return (
              <Card
                key={game.title}
                className="group hover:shadow-2xl transition-all duration-300 cursor-pointer transform hover:-translate-y-2"
                onClick={() => navigate(game.path)}
              >
                <CardHeader>
                  <div className={`h-40 rounded-lg bg-gradient-to-br ${game.gradient} mb-4 flex items-center justify-center group-hover:scale-105 transition-transform`}>
                    <span className="text-6xl">🎮</span>
                  </div>
                  <CardTitle className="text-2xl">{game.title}</CardTitle>
                  <CardDescription>{game.description}</CardDescription>
                  <div className="mt-2 text-sm font-semibold text-primary">
                    Meilleur score: {bestScore}
                  </div>
                </CardHeader>
                <CardContent>
                  <Button className="w-full" variant="default">
                    Jouer Maintenant
                  </Button>
                </CardContent>
              </Card>
            );
          })}
        </div>
      </section>

      {/* Features Section */}
      <section className="container mx-auto px-4 py-16">
        <h3 className="text-3xl font-bold text-center mb-12">Caractéristiques</h3>
        <div className="grid md:grid-cols-3 gap-8">
          <div className="text-center p-6 rounded-lg bg-card">
            <div className="text-4xl mb-4">🎯</div>
            <h4 className="text-xl font-semibold mb-2">Graphismes 3D</h4>
            <p className="text-muted-foreground">Expérience visuelle immersive avec Three.js</p>
          </div>
          <div className="text-center p-6 rounded-lg bg-card">
            <div className="text-4xl mb-4">⚡</div>
            <h4 className="text-xl font-semibold mb-2">Performance</h4>
            <p className="text-muted-foreground">Gameplay fluide et réactif</p>
          </div>
          <div className="text-center p-6 rounded-lg bg-card">
            <div className="text-4xl mb-4">🏆</div>
            <h4 className="text-xl font-semibold mb-2">Scores Sauvegardés</h4>
            <p className="text-muted-foreground">Suivez vos meilleurs scores</p>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t bg-card/50 backdrop-blur-sm mt-16">
        <div className="container mx-auto px-4 py-8 text-center text-muted-foreground">
          <p>Plateforme de Jeux 3D - Propulsé par React Three Fiber</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
