import { Canvas } from '@react-three/fiber';
import { OrbitControls, Sphere, Box, Line } from '@react-three/drei';
import { useRef, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { updateUserScore, getUserScore } from '@/utils/userManager';
import * as THREE from 'three';

const LANES = [-1.5, -0.5, 0.5, 1.5];
const ENEMY_COLORS = ['#ff0000', '#ffff00', '#00ff00', '#ff00ff'];

interface Enemy {
  id: number;
  lane: number;
  z: number;
  color: string;
}

const Player = ({ lane, gameOver }: { lane: number; gameOver: boolean }) => {
  return (
    <Sphere args={[0.3, 32, 32]} position={[LANES[lane], 0.3, 5]}>
      <meshStandardMaterial color="#0088ff" emissive="#0088ff" emissiveIntensity={0.5} />
    </Sphere>
  );
};

const EnemyBall = ({ enemy }: { enemy: Enemy }) => {
  return (
    <Sphere args={[0.3, 32, 32]} position={[LANES[enemy.lane], 0.3, enemy.z]}>
      <meshStandardMaterial color={enemy.color} emissive={enemy.color} emissiveIntensity={0.3} />
    </Sphere>
  );
};

const Road = () => {
  return (
    <>
      <Box args={[8, 0.1, 40]} position={[0, 0, -15]}>
        <meshStandardMaterial color="#333333" />
      </Box>
      
      {/* White borders around the game area */}
      <Line
        points={[
          [-4, 0, 5],
          [-4, 0, -35],
        ]}
        color="white"
        lineWidth={2}
      />
      <Line
        points={[
          [4, 0, 5],
          [4, 0, -35],
        ]}
        color="white"
        lineWidth={2}
      />
      <Line
        points={[
          [-4, 0, 5],
          [4, 0, 5],
        ]}
        color="white"
        lineWidth={2}
      />
      <Line
        points={[
          [-4, 0, -35],
          [4, 0, -35],
        ]}
        color="white"
        lineWidth={2}
      />
    </>
  );
};

const BallRider = () => {
  const navigate = useNavigate();
  const [lane, setLane] = useState(1);
  const [enemies, setEnemies] = useState<Enemy[]>([]);
  const [lives, setLives] = useState(3);
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [bestScore, setBestScore] = useState(0);
  const enemyIdRef = useRef(0);

  useEffect(() => {
    setBestScore(getUserScore('ballrider'));
  }, []);

  useEffect(() => {
    if (gameOver) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'ArrowRight' || e.key === 'd' || e.key === 'D') {
        setLane(prev => Math.min(3, prev + 1));
      } else if (e.key === 'ArrowLeft' || e.key === 'g' || e.key === 'G') {
        setLane(prev => Math.max(0, prev - 1));
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [gameOver]);

  useEffect(() => {
    if (gameOver) return;

    const spawnInterval = setInterval(() => {
      const randomLane = Math.floor(Math.random() * 4);
      const randomColor = ENEMY_COLORS[Math.floor(Math.random() * ENEMY_COLORS.length)];
      setEnemies(prev => [...prev, {
        id: enemyIdRef.current++,
        lane: randomLane,
        z: -30,
        color: randomColor
      }]);
    }, 1500);

    return () => clearInterval(spawnInterval);
  }, [gameOver]);

  useEffect(() => {
    if (gameOver) return;

    const moveInterval = setInterval(() => {
      setEnemies(prev => {
        const newEnemies = prev
          .map(enemy => ({ ...enemy, z: enemy.z + 0.5 }))
          .filter(enemy => enemy.z < 10);

        // Check collisions
        newEnemies.forEach(enemy => {
          if (enemy.lane === lane && enemy.z > 4 && enemy.z < 6) {
            setLives(l => {
              const newLives = l - 1;
              if (newLives <= 0) {
                setGameOver(true);
                updateUserScore('ballrider', score);
              }
              return newLives;
            });
            enemy.z = 100; // Remove enemy after collision
          }
        });

        return newEnemies;
      });

      setScore(s => s + 1);
    }, 50);

    return () => clearInterval(moveInterval);
  }, [gameOver, lane]);

  const handleRestart = () => {
    setLane(1);
    setEnemies([]);
    setLives(3);
    setScore(0);
    setGameOver(false);
    enemyIdRef.current = 0;
    setBestScore(getUserScore('ballrider'));
  };

  return (
    <div className="relative w-full h-screen bg-background">
      <Canvas camera={{ position: [0, 8, 10], fov: 60 }}>
        <ambientLight intensity={0.3} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <pointLight position={[0, 5, 0]} intensity={0.5} color="#0088ff" />
        
        <Road />
        <Player lane={lane} gameOver={gameOver} />
        {enemies.map(enemy => (
          <EnemyBall key={enemy.id} enemy={enemy} />
        ))}
        
        <OrbitControls enableZoom={false} enablePan={false} />
      </Canvas>

      {/* HUD */}
      <div className="absolute top-4 left-4 text-foreground bg-card/80 backdrop-blur-sm p-4 rounded-lg border border-border">
        <div className="text-2xl font-bold">Vies: {lives}</div>
        <div className="text-xl">Score: {score}</div>
        <div className="text-sm text-muted-foreground">Meilleur: {bestScore}</div>
        <div className="text-sm text-muted-foreground mt-2">
          Utilisez ← → ou G D pour bouger
        </div>
      </div>

      <Button
        onClick={() => navigate('/')}
        className="absolute top-4 right-4"
        variant="outline"
      >
        Retour au Menu
      </Button>

      {/* Game Over Screen */}
      {gameOver && (
        <div className="absolute inset-0 bg-background/90 backdrop-blur-md flex items-center justify-center">
          <div className="text-center space-y-6">
            <h1 className="text-6xl font-bold text-destructive">FIN DU JEU</h1>
            <p className="text-3xl text-foreground">Score Final: {score}</p>
            <p className="text-xl text-muted-foreground">Meilleur: {Math.max(score, bestScore)}</p>
            <div className="flex gap-4 justify-center">
              <Button onClick={handleRestart} size="lg">
                Rejouer
              </Button>
              <Button onClick={() => navigate('/')} variant="outline" size="lg">
                Menu Principal
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default BallRider;
