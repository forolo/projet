import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { toast } from 'sonner';

interface User {
  pseudo: string;
  password: string;
  scores: {
    ballrider: number;
    happysnake: number;
    briks: number;
  };
}

const Auth = () => {
  const [isLogin, setIsLogin] = useState(true);
  const [pseudo, setPseudo] = useState('');
  const [password, setPassword] = useState('');
  const navigate = useNavigate();

  useEffect(() => {
    const currentUser = localStorage.getItem('currentUser');
    if (currentUser) {
      navigate('/');
    }
  }, [navigate]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();

    if (!pseudo.trim() || !password.trim()) {
      toast.error('Veuillez remplir tous les champs');
      return;
    }

    const usersData = localStorage.getItem('users');
    const users: User[] = usersData ? JSON.parse(usersData) : [];

    if (isLogin) {
      // Connexion
      const user = users.find(u => u.pseudo === pseudo && u.password === password);
      if (user) {
        localStorage.setItem('currentUser', pseudo);
        toast.success('Connexion réussie !');
        navigate('/');
      } else {
        toast.error('Pseudo ou mot de passe incorrect');
      }
    } else {
      // Inscription
      const existingUser = users.find(u => u.pseudo === pseudo);
      if (existingUser) {
        toast.error('Ce pseudo existe déjà');
        return;
      }

      const newUser: User = {
        pseudo,
        password,
        scores: {
          ballrider: 0,
          happysnake: 0,
          briks: 0
        }
      };

      users.push(newUser);
      localStorage.setItem('users', JSON.stringify(users));
      localStorage.setItem('currentUser', pseudo);
      toast.success('Compte créé avec succès !');
      navigate('/');
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-background to-muted p-4">
      <Card className="w-full max-w-md">
        <CardHeader>
          <CardTitle className="text-3xl text-center">
            {isLogin ? 'Connexion' : 'Créer un compte'}
          </CardTitle>
          <CardDescription className="text-center">
            {isLogin 
              ? 'Connectez-vous pour jouer et sauvegarder vos scores'
              : 'Créez un compte pour commencer à jouer'}
          </CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="pseudo">Pseudo</Label>
              <Input
                id="pseudo"
                value={pseudo}
                onChange={(e) => setPseudo(e.target.value)}
                placeholder="Votre pseudo"
              />
            </div>
            <div className="space-y-2">
              <Label htmlFor="password">Mot de passe</Label>
              <Input
                id="password"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Votre mot de passe"
              />
            </div>
            <Button type="submit" className="w-full">
              {isLogin ? 'Se connecter' : "S'inscrire"}
            </Button>
            <Button
              type="button"
              variant="ghost"
              className="w-full"
              onClick={() => setIsLogin(!isLogin)}
            >
              {isLogin 
                ? "Pas de compte ? S'inscrire"
                : 'Déjà un compte ? Se connecter'}
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  );
};

export default Auth;
