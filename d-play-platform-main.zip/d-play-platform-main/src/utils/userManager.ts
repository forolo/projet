interface User {
  pseudo: string;
  password: string;
  scores: {
    ballrider: number;
    happysnake: number;
    briks: number;
  };
}

export const getCurrentUser = (): string | null => {
  return localStorage.getItem('currentUser');
};

export const getUserScore = (game: 'ballrider' | 'happysnake' | 'briks'): number => {
  const currentUser = getCurrentUser();
  if (!currentUser) return 0;

  const usersData = localStorage.getItem('users');
  if (!usersData) return 0;

  const users: User[] = JSON.parse(usersData);
  const user = users.find(u => u.pseudo === currentUser);
  
  return user?.scores[game] || 0;
};

export const updateUserScore = (game: 'ballrider' | 'happysnake' | 'briks', score: number) => {
  const currentUser = getCurrentUser();
  if (!currentUser) return;

  const usersData = localStorage.getItem('users');
  if (!usersData) return;

  const users: User[] = JSON.parse(usersData);
  const userIndex = users.findIndex(u => u.pseudo === currentUser);
  
  if (userIndex !== -1) {
    if (score > users[userIndex].scores[game]) {
      users[userIndex].scores[game] = score;
      localStorage.setItem('users', JSON.stringify(users));
    }
  }
};

export const logout = () => {
  localStorage.removeItem('currentUser');
};
