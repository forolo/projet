import { Canvas } from '@react-three/fiber';
import { OrbitControls } from '@react-three/drei';
import { useState, useEffect, useRef } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { updateUserScore, getUserScore } from '@/utils/userManager';

interface Position {
  x: number;
  y: number;
}

type Direction = 'UP' | 'DOWN' | 'LEFT' | 'RIGHT';

const GRID_WIDTH = 40;
const GRID_HEIGHT = 30;
const CELL_SIZE = 10;
const BASE_TICK_SPEED = 150; // ms entre chaque mouvement au niveau 1
const POINTS_PER_LEVEL = 1500; // Points nécessaires pour passer au niveau suivant
const SPEED_INCREASE_PER_LEVEL = 10; // Diminution du tick (plus rapide)

const SnakeSegment = ({ position, isHead }: { position: Position; isHead: boolean }) => {
  // Centrer le serpent dans la grille (décalage pour que 0,0 soit au centre)
  const offsetX = (position.x - GRID_WIDTH / 2 + 0.5) * CELL_SIZE;
  const offsetY = (position.y - GRID_HEIGHT / 2 + 0.5) * CELL_SIZE;
  
  return (
    <mesh position={[offsetX, CELL_SIZE / 2, offsetY]}>
      <boxGeometry args={[CELL_SIZE * 0.9, CELL_SIZE * 0.9, CELL_SIZE * 0.9]} />
      <meshStandardMaterial color={isHead ? "#FFD700" : "yellow"} />
    </mesh>
  );
};

const Food = ({ position }: { position: Position }) => {
  // Centrer la nourriture dans la grille
  const offsetX = (position.x - GRID_WIDTH / 2 + 0.5) * CELL_SIZE;
  const offsetY = (position.y - GRID_HEIGHT / 2 + 0.5) * CELL_SIZE;
  
  return (
    <mesh position={[offsetX, CELL_SIZE / 2, offsetY]}>
      <boxGeometry args={[CELL_SIZE * 0.8, CELL_SIZE * 0.8, CELL_SIZE * 0.8]} />
      <meshStandardMaterial color="red" emissive="red" emissiveIntensity={0.3} />
    </mesh>
  );
};

const Arena = () => {
  const arenaWidth = GRID_WIDTH * CELL_SIZE;
  const arenaHeight = GRID_HEIGHT * CELL_SIZE;
  const wallHeight = 20;
  
  return (
    <group>
      {/* Floor */}
      <mesh rotation={[-Math.PI / 2, 0, 0]} position={[0, 0, 0]}>
        <planeGeometry args={[arenaWidth + 4, arenaHeight + 4]} />
        <meshStandardMaterial color="#1a1a1a" />
      </mesh>

      {/* Grid lines - noir transparent */}
      <gridHelper 
        args={[arenaWidth, GRID_WIDTH, 'rgba(0, 0, 0, 0.3)', 'rgba(0, 0, 0, 0.15)']} 
        position={[0, 0.1, 0]}
      />

      {/* Walls - Magenta color */}
      {/* Front wall */}
      <mesh position={[0, wallHeight / 2, -arenaHeight / 2]}>
        <boxGeometry args={[arenaWidth + 4, wallHeight, 2]} />
        <meshStandardMaterial color="magenta" />
      </mesh>
      {/* Back wall */}
      <mesh position={[0, wallHeight / 2, arenaHeight / 2]}>
        <boxGeometry args={[arenaWidth + 4, wallHeight, 2]} />
        <meshStandardMaterial color="magenta" />
      </mesh>
      {/* Left wall */}
      <mesh position={[-arenaWidth / 2, wallHeight / 2, 0]}>
        <boxGeometry args={[2, wallHeight, arenaHeight + 4]} />
        <meshStandardMaterial color="magenta" />
      </mesh>
      {/* Right wall */}
      <mesh position={[arenaWidth / 2, wallHeight / 2, 0]}>
        <boxGeometry args={[2, wallHeight, arenaHeight + 4]} />
        <meshStandardMaterial color="magenta" />
      </mesh>
    </group>
  );
};

const HappySnake = () => {
  const navigate = useNavigate();
  const [snake, setSnake] = useState<Position[]>([
    { x: Math.floor(GRID_WIDTH / 2), y: Math.floor(GRID_HEIGHT / 2) },
    { x: Math.floor(GRID_WIDTH / 2) - 1, y: Math.floor(GRID_HEIGHT / 2) },
    { x: Math.floor(GRID_WIDTH / 2) - 2, y: Math.floor(GRID_HEIGHT / 2) }
  ]);
  const [direction, setDirection] = useState<Direction>('RIGHT');
  const [foodPos, setFoodPos] = useState<Position>({ x: 0, y: 0 });
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [isPaused, setIsPaused] = useState(false);
  const [bestScore, setBestScore] = useState(0);
  const [level, setLevel] = useState(1);
  const nextDirection = useRef<Direction>('RIGHT');

  // Calculer le niveau basé sur le score
  const calculateLevel = (currentScore: number) => {
    return Math.floor(currentScore / POINTS_PER_LEVEL) + 1;
  };

  // Calculer la vitesse basée sur le niveau
  const calculateTickSpeed = (currentLevel: number) => {
    return Math.max(50, BASE_TICK_SPEED - (currentLevel - 1) * SPEED_INCREASE_PER_LEVEL);
  };

  const spawnFood = (currentSnake: Position[]) => {
    let newPos: Position;
    let attempts = 0;
    do {
      newPos = {
        x: Math.floor(Math.random() * GRID_WIDTH),
        y: Math.floor(Math.random() * GRID_HEIGHT)
      };
      attempts++;
    } while (
      attempts < 100 &&
      currentSnake.some(segment => segment.x === newPos.x && segment.y === newPos.y)
    );
    setFoodPos(newPos);
  };

  useEffect(() => {
    const initialSnake = [
      { x: Math.floor(GRID_WIDTH / 2), y: Math.floor(GRID_HEIGHT / 2) },
      { x: Math.floor(GRID_WIDTH / 2) - 1, y: Math.floor(GRID_HEIGHT / 2) },
      { x: Math.floor(GRID_WIDTH / 2) - 2, y: Math.floor(GRID_HEIGHT / 2) }
    ];
    spawnFood(initialSnake);
    setBestScore(getUserScore('happysnake'));
  }, []);

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      const key = e.key;
      
      // Pause/Resume avec Échap
      if (key === 'Escape') {
        if (!gameOver) {
          setIsPaused(prev => !prev);
        }
        return;
      }

      // Ne pas changer de direction si en pause
      if (isPaused) return;

      const currentDir = nextDirection.current;

      if (key === 'ArrowUp' && currentDir !== 'DOWN') {
        nextDirection.current = 'UP';
      } else if (key === 'ArrowDown' && currentDir !== 'UP') {
        nextDirection.current = 'DOWN';
      } else if (key === 'ArrowLeft' && currentDir !== 'RIGHT') {
        nextDirection.current = 'LEFT';
      } else if (key === 'ArrowRight' && currentDir !== 'LEFT') {
        nextDirection.current = 'RIGHT';
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [isPaused, gameOver]);

  // Mettre à jour le niveau quand le score change
  useEffect(() => {
    const newLevel = calculateLevel(score);
    if (newLevel !== level) {
      setLevel(newLevel);
    }
  }, [score, level]);

  useEffect(() => {
    if (gameOver || isPaused) return;

    const tickSpeed = calculateTickSpeed(level);
    const gameLoop = setInterval(() => {
      setSnake(prevSnake => {
        // Update direction
        const currentDirection = nextDirection.current;
        setDirection(currentDirection);

        // Calculate new head position
        const head = prevSnake[0];
        let newHead: Position;

        switch (currentDirection) {
          case 'UP':
            newHead = { x: head.x, y: head.y - 1 };
            break;
          case 'DOWN':
            newHead = { x: head.x, y: head.y + 1 };
            break;
          case 'LEFT':
            newHead = { x: head.x - 1, y: head.y };
            break;
          case 'RIGHT':
            newHead = { x: head.x + 1, y: head.y };
            break;
        }

        // Check wall collision
        if (
          newHead.x < 0 || 
          newHead.x >= GRID_WIDTH || 
          newHead.y < 0 || 
          newHead.y >= GRID_HEIGHT
        ) {
          setGameOver(true);
          updateUserScore('happysnake', score);
          return prevSnake;
        }

        // Check self collision
        if (prevSnake.some(segment => segment.x === newHead.x && segment.y === newHead.y)) {
          setGameOver(true);
          updateUserScore('happysnake', score);
          return prevSnake;
        }

        // Create new snake
        const newSnake = [newHead, ...prevSnake];

        // Check food collision
        if (newHead.x === foodPos.x && newHead.y === foodPos.y) {
          setScore(s => s + 10);
          spawnFood(newSnake);
          // Don't remove tail - snake grows
          return newSnake;
        } else {
          // Remove tail - snake moves
          newSnake.pop();
          return newSnake;
        }
      });
    }, tickSpeed);

    return () => clearInterval(gameLoop);
  }, [gameOver, isPaused, foodPos, score, level]);

  const handleRestart = () => {
    const initialSnake = [
      { x: Math.floor(GRID_WIDTH / 2), y: Math.floor(GRID_HEIGHT / 2) },
      { x: Math.floor(GRID_WIDTH / 2) - 1, y: Math.floor(GRID_HEIGHT / 2) },
      { x: Math.floor(GRID_WIDTH / 2) - 2, y: Math.floor(GRID_HEIGHT / 2) }
    ];
    setSnake(initialSnake);
    setDirection('RIGHT');
    nextDirection.current = 'RIGHT';
    setScore(0);
    setLevel(1);
    setIsPaused(false);
    setGameOver(false);
    spawnFood(initialSnake);
    setBestScore(getUserScore('happysnake'));
  };

  return (
    <div className="w-full h-screen relative bg-gradient-to-br from-background to-muted">
      <Canvas camera={{ position: [0, 250, 200], fov: 60 }}>
        <ambientLight intensity={0.6} />
        <directionalLight position={[10, 10, 5]} intensity={1} />
        <Arena />
        {snake.map((segment, index) => (
          <SnakeSegment 
            key={`${segment.x}-${segment.y}-${index}`} 
            position={segment} 
            isHead={index === 0}
          />
        ))}
        <Food position={foodPos} />
        <OrbitControls enableZoom={true} enablePan={false} />
      </Canvas>

      {/* HUD */}
      <div className="absolute top-4 left-4 bg-card/90 backdrop-blur-sm p-4 rounded-lg shadow-lg">
        <div className="text-2xl font-bold text-primary">Score: {score}</div>
        <div className="text-sm text-muted-foreground">Meilleur: {bestScore}</div>
        <div className="text-sm font-semibold text-accent mt-2">Niveau: {level}</div>
        <div className="text-xs text-muted-foreground mt-1">Longueur: {snake.length}</div>
      </div>

      <div className="absolute top-4 right-4 bg-card/90 backdrop-blur-sm p-4 rounded-lg shadow-lg max-w-xs">
        <h3 className="font-bold mb-2 text-primary">Contrôles:</h3>
        <ul className="text-sm space-y-1 text-muted-foreground">
          <li>↑ Haut : Aller vers le haut</li>
          <li>↓ Bas : Aller vers le bas</li>
          <li>← Gauche : Aller à gauche</li>
          <li>→ Droite : Aller à droite</li>
          <li>Échap : Pause/Reprendre</li>
        </ul>
        <p className="text-xs text-muted-foreground mt-3 italic">
          Le serpent avance automatiquement !
        </p>
      </div>

      {/* Pause Screen */}
      {isPaused && !gameOver && (
        <div className="absolute inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-card p-8 rounded-lg shadow-2xl text-center max-w-md">
            <h2 className="text-4xl font-bold mb-4 text-primary">Pause</h2>
            <p className="text-lg text-muted-foreground mb-6">
              Appuyez sur Échap pour continuer
            </p>
            <div className="text-sm text-muted-foreground space-y-1">
              <p>Score actuel: {score}</p>
              <p>Niveau: {level}</p>
              <p>Longueur: {snake.length}</p>
            </div>
          </div>
        </div>
      )}

      {/* Game Over Screen */}
      {gameOver && (
        <div className="absolute inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center">
          <div className="bg-card p-8 rounded-lg shadow-2xl text-center max-w-md">
            <h2 className="text-4xl font-bold mb-4 text-destructive">FIN DU JEU</h2>
            <p className="text-2xl mb-2">Score Final: {score}</p>
            <p className="text-lg text-muted-foreground mb-6">Meilleur Score: {Math.max(score, bestScore)}</p>
            <p className="text-sm text-muted-foreground mb-6">
              {snake.some(segment => segment.x === snake[0].x && segment.y === snake[0].y && segment !== snake[0]) 
                ? "Vous vous êtes mordu la queue!" 
                : "Vous avez touché un mur!"}
            </p>
            <div className="flex gap-4 justify-center">
              <Button onClick={handleRestart} size="lg">
                Rejouer
              </Button>
              <Button onClick={() => navigate('/')} variant="outline" size="lg">
                Menu principal
              </Button>
            </div>
          </div>
        </div>
      )}

      {/* Back Button */}
      <div className="absolute bottom-4 left-4">
        <Button onClick={() => navigate('/')} variant="secondary">
          ← Retour au Menu
        </Button>
      </div>
    </div>
  );
};

export default HappySnake;
