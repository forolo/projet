import { Canvas } from '@react-three/fiber';
import { OrbitControls, Box, Line } from '@react-three/drei';
import { useRef, useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import { updateUserScore, getUserScore } from '@/utils/userManager';
import * as THREE from 'three';

const GRID_WIDTH = 10;
const GRID_HEIGHT = 20;
const CELL_SIZE = 0.5;

type TetrominoShape = number[][];

const TETROMINOS: { [key: string]: TetrominoShape } = {
  I: [[1, 1, 1, 1]],
  O: [[1, 1], [1, 1]],
  T: [[0, 1, 0], [1, 1, 1]],
  S: [[0, 1, 1], [1, 1, 0]],
  Z: [[1, 1, 0], [0, 1, 1]],
  J: [[1, 0, 0], [1, 1, 1]],
  L: [[0, 0, 1], [1, 1, 1]]
};

const COLORS: { [key: string]: string } = {
  I: '#00ffff',
  O: '#ffff00',
  T: '#800080',
  S: '#00ff00',
  Z: '#ff0000',
  J: '#0000ff',
  L: '#ffa500'
};

interface Position {
  x: number;
  y: number;
}

const Grid = ({ grid }: { grid: string[][] }) => {
  return (
    <>
      {grid.map((row, y) =>
        row.map((cell, x) => {
          if (cell !== '') {
            return (
              <Box
                key={`${x}-${y}`}
                args={[CELL_SIZE - 0.05, CELL_SIZE - 0.05, CELL_SIZE - 0.05]}
                position={[
                  (x - GRID_WIDTH / 2) * CELL_SIZE,
                  (GRID_HEIGHT - y) * CELL_SIZE,
                  0
                ]}
              >
                <meshStandardMaterial
                  color={cell}
                  emissive={cell}
                  emissiveIntensity={0.3}
                />
              </Box>
            );
          }
          return null;
        })
      )}
    </>
  );
};

const CurrentPiece = ({ shape, position, color }: { shape: TetrominoShape; position: Position; color: string }) => {
  return (
    <>
      {shape.map((row, dy) =>
        row.map((cell, dx) => {
          if (cell) {
            return (
              <Box
                key={`${dx}-${dy}`}
                args={[CELL_SIZE - 0.05, CELL_SIZE - 0.05, CELL_SIZE - 0.05]}
                position={[
                  ((position.x + dx) - GRID_WIDTH / 2) * CELL_SIZE,
                  (GRID_HEIGHT - (position.y + dy)) * CELL_SIZE,
                  0
                ]}
              >
                <meshStandardMaterial
                  color={color}
                  emissive={color}
                  emissiveIntensity={0.5}
                />
              </Box>
            );
          }
          return null;
        })
      )}
    </>
  );
};

const Briks = () => {
  const navigate = useNavigate();
  const [grid, setGrid] = useState<string[][]>(
    Array(GRID_HEIGHT).fill(null).map(() => Array(GRID_WIDTH).fill(''))
  );
  const [currentPiece, setCurrentPiece] = useState<string>('T');
  const [currentShape, setCurrentShape] = useState<TetrominoShape>(TETROMINOS.T);
  const [position, setPosition] = useState<Position>({ x: 4, y: 0 });
  const [score, setScore] = useState(0);
  const [gameOver, setGameOver] = useState(false);
  const [bestScore, setBestScore] = useState(0);
  const [nextPiece, setNextPiece] = useState<string>('I');
  const dropSpeed = useRef(500);

  const randomPiece = () => {
    const pieces = Object.keys(TETROMINOS);
    const newNextPiece = pieces[Math.floor(Math.random() * pieces.length)];
    
    setCurrentPiece(nextPiece);
    setCurrentShape(TETROMINOS[nextPiece]);
    setNextPiece(newNextPiece);
    setPosition({ x: Math.floor(GRID_WIDTH / 2) - 1, y: 0 });
  };

  const rotatePiece = () => {
    const rotated = currentShape[0].map((_, i) =>
      currentShape.map(row => row[i]).reverse()
    );
    
    // Check if rotation is valid
    if (!checkCollision(rotated, position)) {
      setCurrentShape(rotated);
    }
  };

  const checkCollision = (shape: TetrominoShape, pos: Position): boolean => {
    for (let dy = 0; dy < shape.length; dy++) {
      for (let dx = 0; dx < shape[dy].length; dx++) {
        if (shape[dy][dx]) {
          const newX = pos.x + dx;
          const newY = pos.y + dy;
          
          if (newX < 0 || newX >= GRID_WIDTH || newY >= GRID_HEIGHT) {
            return true;
          }
          
          if (newY >= 0 && grid[newY][newX] !== '') {
            return true;
          }
        }
      }
    }
    return false;
  };

  const mergePiece = () => {
    const newGrid = grid.map(row => [...row]);
    currentShape.forEach((row, dy) => {
      row.forEach((cell, dx) => {
        if (cell && position.y + dy >= 0) {
          newGrid[position.y + dy][position.x + dx] = COLORS[currentPiece];
        }
      });
    });
    setGrid(newGrid);
    
    // Check for completed lines
    let linesCleared = 0;
    const filteredGrid = newGrid.filter(row => {
      if (row.every(cell => cell !== '')) {
        linesCleared++;
        return false;
      }
      return true;
    });
    
    while (filteredGrid.length < GRID_HEIGHT) {
      filteredGrid.unshift(Array(GRID_WIDTH).fill(''));
    }
    
    if (linesCleared > 0) {
      setGrid(filteredGrid);
      setScore(s => s + linesCleared * 100);
    }
    
    randomPiece();
  };

  useEffect(() => {
    const pieces = Object.keys(TETROMINOS);
    const firstNext = pieces[Math.floor(Math.random() * pieces.length)];
    setNextPiece(firstNext);
    randomPiece();
    setBestScore(getUserScore('briks'));
  }, []);

  useEffect(() => {
    if (gameOver) return;

    const handleKeyDown = (e: KeyboardEvent) => {
      switch (e.key) {
        case 'ArrowLeft':
          const leftPos = { ...position, x: position.x - 1 };
          if (!checkCollision(currentShape, leftPos)) {
            setPosition(leftPos);
          }
          break;
        case 'ArrowRight':
          const rightPos = { ...position, x: position.x + 1 };
          if (!checkCollision(currentShape, rightPos)) {
            setPosition(rightPos);
          }
          break;
        case 'ArrowUp':
          rotatePiece();
          break;
        case 'ArrowDown':
          dropSpeed.current = 50;
          break;
      }
    };

    const handleKeyUp = (e: KeyboardEvent) => {
      if (e.key === 'ArrowDown') {
        dropSpeed.current = 500;
      }
    };

    window.addEventListener('keydown', handleKeyDown);
    window.addEventListener('keyup', handleKeyUp);
    return () => {
      window.removeEventListener('keydown', handleKeyDown);
      window.removeEventListener('keyup', handleKeyUp);
    };
  }, [gameOver, currentShape, position]);

  useEffect(() => {
    if (gameOver) return;

      const dropInterval = setInterval(() => {
      const newPos = { ...position, y: position.y + 1 };
      
      if (checkCollision(currentShape, newPos)) {
        if (position.y <= 1) {
          setGameOver(true);
          updateUserScore('briks', score);
        } else {
          mergePiece();
        }
      } else {
        setPosition(newPos);
      }
    }, dropSpeed.current);

    return () => clearInterval(dropInterval);
  }, [position, currentShape, gameOver]);

  const handleRestart = () => {
    const pieces = Object.keys(TETROMINOS);
    const firstNext = pieces[Math.floor(Math.random() * pieces.length)];
    setNextPiece(firstNext);
    setGrid(Array(GRID_HEIGHT).fill(null).map(() => Array(GRID_WIDTH).fill('')));
    setScore(0);
    setGameOver(false);
    randomPiece();
    dropSpeed.current = 500;
    setBestScore(getUserScore('briks'));
  };

  return (
    <div className="relative w-full h-screen bg-background">
      <Canvas camera={{ position: [0, GRID_HEIGHT * CELL_SIZE / 2, 15], fov: 60 }}>
        <ambientLight intensity={0.4} />
        <directionalLight position={[10, 20, 10]} intensity={1} />
        <pointLight position={[0, 10, 5]} intensity={0.5} color="#0088ff" />
        
        {/* Grid background */}
        <Box
          args={[GRID_WIDTH * CELL_SIZE, GRID_HEIGHT * CELL_SIZE, 0.1]}
          position={[0, GRID_HEIGHT * CELL_SIZE / 2, -0.1]}
        >
          <meshStandardMaterial color="#1a1a1a" />
        </Box>
        
        {/* White border around game area */}
        <Line
          points={[
            [-GRID_WIDTH * CELL_SIZE / 2, 0, 0],
            [-GRID_WIDTH * CELL_SIZE / 2, GRID_HEIGHT * CELL_SIZE, 0],
            [GRID_WIDTH * CELL_SIZE / 2, GRID_HEIGHT * CELL_SIZE, 0],
            [GRID_WIDTH * CELL_SIZE / 2, 0, 0],
            [-GRID_WIDTH * CELL_SIZE / 2, 0, 0],
          ]}
          color="white"
          lineWidth={2}
        />
        
        <Grid grid={grid} />
        
        {/* Grid lines - horizontal */}
        {Array.from({ length: GRID_HEIGHT + 1 }).map((_, i) => (
          <Line
            key={`h-${i}`}
            points={[
              [-GRID_WIDTH * CELL_SIZE / 2, i * CELL_SIZE, 0.05],
              [GRID_WIDTH * CELL_SIZE / 2, i * CELL_SIZE, 0.05]
            ]}
            color="white"
            lineWidth={0.5}
            opacity={0.3}
          />
        ))}
        
        {/* Grid lines - vertical */}
        {Array.from({ length: GRID_WIDTH + 1 }).map((_, i) => (
          <Line
            key={`v-${i}`}
            points={[
              [-GRID_WIDTH * CELL_SIZE / 2 + i * CELL_SIZE, 0, 0.05],
              [-GRID_WIDTH * CELL_SIZE / 2 + i * CELL_SIZE, GRID_HEIGHT * CELL_SIZE, 0.05]
            ]}
            color="white"
            lineWidth={0.5}
            opacity={0.3}
          />
        ))}
        
        {!gameOver && (
          <CurrentPiece
            shape={currentShape}
            position={position}
            color={COLORS[currentPiece]}
          />
        )}
        
        <OrbitControls enableZoom={true} enablePan={false} />
      </Canvas>

      {/* HUD */}
      <div className="absolute top-4 left-4 text-foreground bg-card/80 backdrop-blur-sm p-4 rounded-lg border border-border">
        <div className="text-2xl font-bold">Score: {score}</div>
        <div className="text-sm text-muted-foreground">Meilleur: {bestScore}</div>
        <div className="text-sm text-muted-foreground mt-2">
          ← → Déplacer<br />
          ↑ Rotation<br />
          ↓ Chute Rapide
        </div>
      </div>

      {/* Next Piece Preview */}
      <div className="absolute top-4 right-24 text-foreground bg-card/80 backdrop-blur-sm p-4 rounded-lg border border-border">
        <div className="text-sm font-bold mb-2 text-center">Prochain</div>
        <div className="flex items-center justify-center" style={{ width: '80px', height: '80px' }}>
          {TETROMINOS[nextPiece].map((row, dy) => (
            <div key={dy} className="flex flex-col">
              {row.map((cell, dx) => (
                <div
                  key={`${dx}-${dy}`}
                  style={{
                    width: '16px',
                    height: '16px',
                    backgroundColor: cell ? COLORS[nextPiece] : 'transparent',
                    border: cell ? '1px solid rgba(255,255,255,0.2)' : 'none',
                    boxShadow: cell ? `0 0 8px ${COLORS[nextPiece]}` : 'none'
                  }}
                />
              ))}
            </div>
          ))}
        </div>
      </div>

      <Button
        onClick={() => navigate('/')}
        className="absolute top-4 right-4"
        variant="outline"
      >
        Retour au Menu
      </Button>

      {/* Game Over Screen */}
      {gameOver && (
        <div className="absolute inset-0 bg-background/90 backdrop-blur-md flex items-center justify-center">
          <div className="text-center space-y-6">
            <h1 className="text-6xl font-bold text-destructive">FIN DU JEU</h1>
            <p className="text-3xl text-foreground">Score Final: {score}</p>
            <p className="text-xl text-muted-foreground">Meilleur: {Math.max(score, bestScore)}</p>
            <div className="flex gap-4 justify-center">
              <Button onClick={handleRestart} size="lg">
                Rejouer
              </Button>
              <Button onClick={() => navigate('/')} variant="outline" size="lg">
                Menu Principal
              </Button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default Briks;
